package main.hotel_registro;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class Application extends javafx.application.Application {

    public static Stage LoginStage;
    public static Stage RegisterStage;
    public static Stage ReserveStage;
    public static Stage RecovpassStage;
    public static Stage MiPerfilStage;
    public static Stage MiPerfilAdminStage;
    public static Stage RecovPassEmailCode;

    public static Stage NuevaContrasena;




    @FXML
    @Override
    public void start(Stage stage) throws IOException {
        /**
         * Ventana principal.
         */

        FXMLLoader loader = new FXMLLoader(getClass().getResource("Reserve.fxml"));
        Controller controller = loader.getController();
        Parent root = loader.load();
        Scene scene = new Scene(root, 830, 710);
        stage.getIcons().add(new Image(("file:logo.png")));
        stage.setTitle("Reservas");
        stage.setScene(scene);
        stage.show();
        ReserveStage = stage;

        stage.setResizable(false);


    }
    @FXML
    public static void main(String[] args) {
        launch();
    }











    public void newpassword() throws IOException {
        /**
         * Ventana de codigo para recuperar contraseña.
         */
        FXMLLoader loader = new FXMLLoader(getClass().getResource("NuevaContrasena.fxml"));
        Controller controller = loader.getController();
        Parent root = loader.load();

        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.getIcons().add(new Image(("file:logo.png")));
        stage.setTitle("Nueva Contraseña");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
         NuevaContrasena= stage;
        stage.setResizable(false);


}}