module main.hotel_registro {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires java.desktop;
    requires java.sql;
    requires java.mail;


    opens main.hotel_registro to javafx.fxml;
    exports main.hotel_registro;
}