package main.hotel_registro;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.security.InvalidParameterException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.Properties;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressWarnings({})
public class Controller  {

    public static Stage LoginStage;
    public static Stage RegisterStage;
    public static Stage ReserveStage;
    public static Stage RecovpassStage;
    public static Stage MiPerfilStage;
    public static Stage MiPerfilAdminStage;
    public static Stage RecovPassEmailCode;

    public static Stage NuevaContrasena;
    public static int idreserva;
    public final String DB_URL = "jdbc:mysql://192.168.1.153:3306/hotelgestion";
    public final String USERNAME = "root";
    public final String PASSWORD = "";
    /**
     * Credenciales para la base de datos del servidor.
     *
     * CONTRASEÑA DEL SERVIDOR = Bteam2323+
     */

    public static final Button RESERVAR = new Button();
    public static boolean EMAILREPETIDO = false;
    public static final AnchorPane MAINANCHORINICIO = new AnchorPane();
    private static boolean CONECTADO = false;
    private static boolean ADMIN = false;

    /**
     * Regular expresion para validar el email.
     */
    public static final Pattern emailRegex =
            Pattern.compile("^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$", Pattern.CASE_INSENSITIVE);
    /**
     * Regular expresion para validar el telefono.
     */
    private static final String phoneRegex = "^\\d{3}-\\d{3}-\\d{3}$";

    public static String EmailUsuario2;
    public static String EmailUsuario;
    public static boolean nombre = false;
    public static boolean apellido = false;
    public static boolean contrasena = false;
    public static boolean telefono = false;
    public static String PHONE;
    public static String NOMBRE;
    public static String APELLIDO;
    public static String EMAIL;
    public static String PASS;
    public static String CYPHERPASS;
    public static String CYPHERPASS2 = null;
    public TextField emailtx;
    public PasswordField passtx;
    public TextField apellidotx;
    public TextField nombretx;
    public TextField phonetx;
    public Label labelsurnameneed;
    public Label labelphoneneed;
    public Label labelmailneed;
    public Label labelnameneed;
    public Label labelpassneed;
    public PasswordField passs;
    public TextField corrr;
    public Label labelemail2;
    public Label labelpass2;
    public static Button IniciarSesionHL;
    public static Button RegistrarseHL;

    public static String generatedString;
    public static ImageView Room1IMG;
    public Label labeldate1;
    public Label labelsalida;
    public Label labelprecio;
    public DatePicker calendar1;
    public DatePicker calendar2;
    public Label totalprize;
    public Label labeldateneeded;
    public Label labeldateneeded2;
    public Label labelreservado;
    public Label labeldisponibleapartir;
    public Label labelfechadisponible;
    public Pane room1pane;
    public Button CerrarSesionHL;

    public static String mysqlemail;

    @FXML
    public Label roomtitle;
    public Label roomtext;

    public TextField recovpasstextfield;
    public TextField codeemailtextfield;
    public TextField cambiarcontratx1;
    public TextField cambiarcontratx2;
    public TextField cancelartx;


    private static String emailtoString;
    private static String passtoString;


    public static boolean validateEmail(String emailStr) {
        Matcher matcher = emailRegex.matcher(emailStr);
        return matcher.find();
    }

    public void onbuttonregister(ActionEvent actionEvent) throws IOException {
        /**
         * Ventana de registro.
         */
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Registro.fxml"));
        Controller controller = loader.getController();
        Parent root = loader.load();

        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.getIcons().add(new Image(("file:logo.png")));
        stage.setTitle("Registro");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
        RegisterStage = stage;
        stage.setResizable(false);
    }

    public void onbuttonrecovpass(ActionEvent actionEvent) throws IOException {
        /**
         * Venta para recuperar contraseña.
         */
        FXMLLoader loader = new FXMLLoader(getClass().getResource("RecuperarContrasena.fxml"));
        Controller controller = loader.getController();
        Parent root = loader.load();

        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.getIcons().add(new Image(("file:logo.png")));
        stage.setTitle("Recuperar contraseña");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
        RecovpassStage = stage;
        stage.setResizable(false);
    }

    /**
     * @param actionEvent
     * @throws SQLException
     * @throws ClassNotFoundException
     * @throws InvocationTargetException
     *
     * Action event al darle al boton registrar.
     *
     *
     */
    public void registrar(ActionEvent actionEvent) throws SQLException, ClassNotFoundException, InvocationTargetException {
        try {
            if (nombretx.getText().equals("")) {
                labelnameneed.setText("Debes introducir tu nombre.");
            } else {
                labelnameneed.setText("");

                NOMBRE = nombretx.getText();
                nombre = true;
            }
            if (apellidotx.getText().equals("")) {
                labelsurnameneed.setText("Debes introducir tu apellido.");
            } else {
                labelsurnameneed.setText("");

                APELLIDO = apellidotx.getText();
                apellido = true;
            }
            if (emailtx.getText().equals("")) {
                labelmailneed.setText("Debes introducir un correo electrónico.");
            } else {
                labelmailneed.setText("");
                EMAIL = emailtx.getText();
                if (validateEmail(EMAIL) == false)
                    labelmailneed.setText("El email introducido no es válido.");


            }


            if (passtx.getText().equals("")) {
                labelpassneed.setText("Debes introducir una contraseña.");
            } else {
                labelpassneed.setText("");

                PASS = passtx.getText();

                CYPHERPASS = null;
                try {
                    MessageDigest md = MessageDigest.getInstance("MD5");
                    md.update(PASS.getBytes());
                    byte[] bytes = md.digest();
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < bytes.length; i++) {
                        sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
                    }
                    CYPHERPASS = sb.toString();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
                contrasena = true;
            }
            //Implementar validar contraseña.
            if (phonetx.getText().equals("")) {
                labelphoneneed.setText("Debes introducir un número de teléfono.");
            }
            if (phonetx.getText().matches("[0-9]+") && phonetx.getText()
                    .length() == 9) {
                labelphoneneed.setText("");
                try {
                    PHONE = phonetx.getText();
                } catch (NumberFormatException e) {
                    System.out.println("Error: The string is not a valid number representation.");
                }
                telefono = true;

            } else {
                labelphoneneed.setText("Tienes que introducir un número válido");
            }
            if (validateEmail(EMAIL) == true && nombre == true && apellido == true && telefono == true && contrasena == true) {

                /**
                 * Si todos los campos son correctos se hace el insert en la base de datos.
                 */

                databaseInsert();
            }

        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }


    public void onbuttoniniciar(ActionEvent actionEvent) throws IOException {
        /**
         * Ventana de inicio de sesión.
         */

        FXMLLoader loader = new FXMLLoader(getClass().getResource("InicioSesion.fxml"));
        Controller controller = loader.getController();
        Parent root = loader.load();

        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.getIcons().add(new Image(("file:logo.png")));
        stage.setTitle("Iniciar Sesión");
        stage.setScene(scene);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.show();
        LoginStage = stage;
        stage.setResizable(false);
    }


    public void databaseInsert() throws Exception {

        if (EMAILREPETIDO == true) {
            JOptionPane.showMessageDialog(null, "Ya hay una cuenta de usuario con ese email");
        } else {
            try {
                final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
                final String DB_URL = "jdbc:mysql://192.168.1.153:3306/hotelgestion";

                final String USER = "root";
                final String PASS = "";

                Connection conn = null;
                Statement stmt = null;

                try {
                    Class.forName(JDBC_DRIVER);

                    conn = DriverManager.getConnection(DB_URL, USER, PASS);

                    stmt = conn.createStatement();

                    String sql = "INSERT INTO usuario" + "(nombre, apellido, correo, contrasena, telefono, tipoUsuario)" + "VALUES (?,?,?,?,?,?)";
                    PreparedStatement preparedStatement = conn.prepareStatement(sql);
                    preparedStatement.setString(1, NOMBRE);
                    preparedStatement.setString(2, APELLIDO);
                    preparedStatement.setString(3, EMAIL);
                    preparedStatement.setString(4, CYPHERPASS);
                    preparedStatement.setString(5, PHONE);
                    preparedStatement.setString(6, "cliente");

                    EmailUsuario = EMAIL;
                    preparedStatement.executeUpdate();

                    stmt.executeUpdate(sql);


                } finally {
                    try {
                        if (stmt != null)
                            stmt.close();
                    } catch (SQLException se2) {
                    }
                    try {
                        if (conn != null)
                            conn.close();
                    } catch (SQLException se) {
                    }
                }


            } catch (SQLSyntaxErrorException e) {
                System.out.println("Datos registrados con éxito");
                JOptionPane.showMessageDialog(null, "Registro realizado con éxito");
                this.getClass();


                CONECTADO = true;
                RegisterStage.hide();
                EmailUsuario2 = EMAIL;


                try {
                    Mail m = new Mail("C:\\Users\\Iker\\IdeaProjects\\Hotel_Registro\\src\\main\\java\\main\\hotel_registro\\config.prop");
                    m.enviarEmail("Registro realizado en el servicio de habitaciones Continental", "El registro se ha realizado con los siguientes datos:" + "\r\n" +
                            "Nombre: " + NOMBRE + " " + APELLIDO + "\r\n" + "Teléfono de contacto: " + PHONE, EMAIL);
                    String correo = ("ik.cao@aulanz.net");

                } catch (InvalidParameterException | IOException | MessagingException ex) {
                    System.out.println(ex.getMessage());
                }

            }
        }


    }

    public void iniciarSesion() {


    }

    @SuppressWarnings({})
    public void onbuttoniciarinicio(ActionEvent actionEvent) throws InvocationTargetException, ClassCastException {


        try {
            emailtoString = corrr.getText();
            passtoString = passs.getText();
            CYPHERPASS2 = null;
            if (passtoString.equals("")) {
                labelpass2.setText("Debes introducir una contraseña.");
            }
            if (emailtoString.equals("")) {
                labelemail2.setText("Debes introducir un correo electrónico.");
            }
            if (validateEmail((emailtoString)) == false)
                labelemail2.setText("El email introducido no es válido.");


            else {


                MessageDigest md = MessageDigest.getInstance("MD5");
                md.update(passtoString.getBytes()); // Tu contraseña
                byte[] bytes = md.digest();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < bytes.length; i++) {
                    sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
                }
                CYPHERPASS2 = sb.toString();  // <<<-----------------------
                /**
                 * Aqui la variable que quieras que tenga la contraseña cifrada.
                 */


            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }


        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

            System.out.println("Creating statement...");
            String sql = "SELECT * FROM usuario WHERE correo = ? and contrasena = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, emailtoString);
            stmt.setString(2, CYPHERPASS2);
            ResultSet rs = stmt.executeQuery();
            System.out.println("email:   " + emailtoString + "contraseña cifrada:    " + CYPHERPASS2);


            if (rs.next()) {
                int id = rs.getInt(1);

                String tipoUsuario = String.valueOf(rs.getString("tipoUsuario"));
                System.out.println("Sign in successful. User ID: " + id + "Tipo de usuario: " + tipoUsuario);
                CONECTADO = true;

                JOptionPane.showMessageDialog(null, "Inicio de sesión correcto");
                if (tipoUsuario.equals("admin"))
                    ADMIN = true;

                EmailUsuario2 = emailtoString;
                LoginStage.hide();


            } else {
                JOptionPane.showMessageDialog(null, "El usuario o la contraseña son incorrectas.");
                System.out.println("Sign in failed");
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }


        }
    }







    public void OnIniciarSesionHL(ActionEvent actionEvent) throws IOException {
        if (CONECTADO == true) {
            JOptionPane.showMessageDialog(null, "Ya has iniciado sesión.");
        } else {
            /**
             * Ventana de inicio de sesión.
             */

            FXMLLoader loader = new FXMLLoader(getClass().getResource("InicioSesion.fxml"));
            Controller controller = loader.getController();
            Parent root = loader.load();

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.getIcons().add(new Image(("file:logo.png")));
            stage.setTitle("Iniciar Sesión");
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
            LoginStage = stage;
            stage.setResizable(false);
        }

    }

    public void OnRegistrarseHL(ActionEvent actionEvent) throws IOException {
        if (CONECTADO == true) {
            JOptionPane.showMessageDialog(null, "Ya has iniciado sesión.");

        } else {
            /**
             * Ventana de registro.
             */
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Registro.fxml"));
            Controller controller = loader.getController();
            Parent root = loader.load();

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.getIcons().add(new Image(("file:logo.png")));
            stage.setTitle("Registro");
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
            RegisterStage = stage;
            stage.setResizable(false);
        }

    }

    public void OnCerrarSesionHL(ActionEvent actionEvent) {
        CONECTADO = false;

    }

    public void OnButtonCerrarSesion(ActionEvent actionEvent) {

        if (CONECTADO == true) {

            JOptionPane.showMessageDialog(null, "Has cerrado sesión.");


            ADMIN = false;
            CONECTADO = false;
        } else
            JOptionPane.showMessageDialog(null, "Aun no has iniciado sesión.");


    }

    public void GetDate1(ActionEvent actionEvent) {


        labeldate1.setText(calendar1.getValue().toString());
        if (calendar2.getValue() == null) {
            System.out.println("Segunda fecha requerida");
        } else {
            String substring = calendar1.getValue().toString().substring(Math.max(calendar1.getValue().toString().length() - 2, 0));
            String substring2 = calendar2.getValue().toString().substring(Math.max(calendar2.getValue().toString().length() - 2, 0));
            int diaselegidos = Integer.parseInt(substring) - Integer.parseInt(substring2);
            totalprize.setText(String.valueOf(Math.abs(diaselegidos * 68)) + "€");
        }


    }

    public void GetDate2(ActionEvent actionEvent) {

        labelsalida.setText(calendar2.getValue().toString());
        if (calendar1.getValue() == null) {
            System.out.println("Primera fecha requerida");
        } else {
            String substring = calendar1.getValue().toString().substring(Math.max(calendar1.getValue().toString().length() - 2, 0));
            String substring2 = calendar2.getValue().toString().substring(Math.max(calendar2.getValue().toString().length() - 2, 0));
            int diaselegidos = Integer.parseInt(substring) - Integer.parseInt(substring2);
            totalprize.setText(String.valueOf(Math.abs(diaselegidos * 68)) + "€");
        }

    }




    public void OnButtonRESERVAR(ActionEvent actionEvent) {
        int idhabitacion = 1;
        if (CONECTADO == false)
            JOptionPane.showMessageDialog(null, "Debes estar registrado para poder reservar una habitación.");
        else {
            if (calendar1.getValue() == null)
                labeldateneeded.setText("Debes introducir una fecha de entrada.");


            if (calendar2.getValue() == null)
                labeldateneeded2.setText("Debes introducir una fecha de salida.");

            if ((calendar1.getValue() != null) && (calendar2.getValue() != null)) {
                int input = JOptionPane.showConfirmDialog(null, "¿Seguro que desea hacer la reserva?");
                System.out.println(input);
                if (input == 0) {
                    Connection conn = null;
                    PreparedStatement stmt = null;
                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");

                        System.out.println("Connecting to database...");
                        conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

                        System.out.println("Creating statement...");
                        String sql = "UPDATE habitaciones SET disponible = 1 WHERE id_habitacion LIKE 1";
                        stmt = conn.prepareStatement(sql);
                        int rs = stmt.executeUpdate();
                        System.out.println("Reserva realizada con exito");
                        System.out.println(rs);

                        stmt.close();
                        conn.close();
                    } catch (SQLException se) {
                        se.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (stmt != null) {
                                stmt.close();
                            }
                        } catch (SQLException se2) {
                        }
                        try {
                            if (conn != null) {
                                conn.close();
                            }
                        } catch (SQLException se) {
                            se.printStackTrace();
                        }
                    }
                    conn = null;
                    stmt = null;
                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");

                        System.out.println("Connecting to database...");
                        conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

                        System.out.println("Creating statement...");
                        String sql = "INSERT INTO reservas" + "(idhabitacion, correousuario, fechaentrada, fechasalida)" + "VALUES (?,?,?,?)";
                        stmt = conn.prepareStatement(sql);
                        stmt.setString(1, String.valueOf(idhabitacion));
                        stmt.setString(2, EmailUsuario2);
                        stmt.setString(3, String.valueOf(calendar1.getValue()));
                        stmt.setString(4, String.valueOf(calendar2.getValue()));


                        int rs = stmt.executeUpdate();
                        System.out.println("Reserva realizada con exito");

                        System.out.println(rs);
                        stmt = null;
                        sql = "SELECT * FROM reservas WHERE correousuario = ?";
                        stmt = conn.prepareStatement(sql);
                        stmt.setString(1, EmailUsuario2);
                        ResultSet rs2 = stmt.executeQuery();

                        rs2.next();
                        idreserva = rs2.getInt(1);


                        stmt.close();
                        conn.close();
                    } catch (SQLException se) {
                        se.printStackTrace();
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        try {
                            if (stmt != null) {
                                stmt.close();
                            }
                        } catch (SQLException se2) {
                        }
                        try {
                            if (conn != null) {
                                conn.close();
                            }
                        } catch (SQLException se) {
                            se.printStackTrace();
                        }


                    }
                    try {
                        Mail m = new Mail("C:\\Users\\Iker\\IdeaProjects\\Hotel_Registro\\src\\main\\java\\main\\hotel_registro\\config.prop");
                        String correo = ("ik.cao@aulanz.net");
                        m.enviarEmail("Reserva realizada con exito en la habitacion numero: " + idhabitacion, "Sus datos de reserva: " + "\r\n" +
                                "ID de la reserva: " + idreserva + " " + "\r\n" + "Email de reserva: " + EmailUsuario2,EmailUsuario2);


                    } catch (InvalidParameterException | IOException | MessagingException ex) {
                        System.out.println(ex.getMessage());
                    }


                    labeldateneeded.setText("");
                    labeldateneeded2.setText("");
                    labelreservado.setText("Reservado");
                    room1pane.setDisable(true);
                    labeldisponibleapartir.setText("Disponlble a partir del:");
                    labelfechadisponible.setText(calendar2.getValue().toString());

                }
            }
        }
    }

    public void onmiperfilbutton(ActionEvent actionEvent) throws IOException {
        if (CONECTADO == false) {
            JOptionPane.showMessageDialog(null, "Debes tener una cuenta para acceder a esta función");
        } else if (ADMIN = true) {


        } else {

        }
    }

    public void aceptarrecovpassbutton(ActionEvent actionEvent) {

        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

            System.out.println("Creating statement...");
            String sql = "SELECT * FROM usuario WHERE correo = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, String.valueOf(recovpasstextfield.getText()));
            ResultSet rs = stmt.executeQuery();


            if (rs.next()) {
                int id = rs.getInt(1);
                System.out.println(id);
                int leftLimit = 97;
                int rightLimit = 122;
                int targetStringLength = 10;
                Random random = new Random();

                generatedString = random.ints(leftLimit, rightLimit + 1)
                        .limit(targetStringLength)
                        .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                        .toString();

                System.out.println(generatedString);
                /**
                 * Ruta para el archivo .prop que contiene el email y la contraseña.
                 */
                try {
                    Mail m = new Mail("C:\\Users\\Iker\\IdeaProjects\\Hotel_Registro\\src\\main\\java\\main\\hotel_registro\\config.prop");
                    m.enviarEmail("Solicitud para cambiar contraseña:", "Introduce el siguiente código en el campo especificado." + "\r\n" +
                            generatedString, String.valueOf(recovpasstextfield.getText()));
                    String correo = ("ik.cao@aulanz.net");
                    mysqlemail = recovpasstextfield.getText();

                } catch (InvalidParameterException | IOException | MessagingException ex) {
                    System.out.println(ex.getMessage());
                }
                RecovpassStage.hide();
                /**
                 * Ventana de codigo para recuperar contraseña.
                 */
                FXMLLoader loader = new FXMLLoader(getClass().getResource("RecovPassCodeEmail.fxml"));
                Controller controller = loader.getController();
                Parent root = loader.load();

                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.getIcons().add(new Image(("file:logo.png")));
                stage.setTitle("Recuperar Contraseña");
                stage.setScene(scene);
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.show();
                RecovPassEmailCode = stage;
                stage.setResizable(false);


            } else {
                System.out.println("No existe ninguna cuenta con este correo.");
                JOptionPane.showMessageDialog(null, "No existe ninguna cuenta con este correo.");
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }


        }

    }

    public void onenviarcodeemail(ActionEvent actionEvent) throws IOException {
        if (codeemailtextfield.getText().equals(generatedString)) {
            RecovPassEmailCode.hide();
            /**
             * Ventana de codigo para recuperar contraseña.
             */
            FXMLLoader loader = new FXMLLoader(getClass().getResource("NuevaContrasena.fxml"));
            Controller controller = loader.getController();
            Parent root = loader.load();

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.getIcons().add(new Image(("file:logo.png")));
            stage.setTitle("Nueva Contraseña");
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
            NuevaContrasena= stage;
            stage.setResizable(false);

        } else {
            System.out.println("El codigo es incorrecto");
            JOptionPane.showMessageDialog(null, "El código introducido no es correcto.");
        }
    }

    public void onbuttoncambiarcontrasena(ActionEvent actionEvent) throws NoSuchAlgorithmException {

        if (cambiarcontratx1.getText().equals(cambiarcontratx2.getText())) {

            String newpass;
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(cambiarcontratx1.getText().getBytes()); // Tu contraseña
            byte[] bytes = md.digest();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            newpass = sb.toString();  // <<<-----------------------

            Connection conn = null;
            PreparedStatement stmt = null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");

                System.out.println("Connecting to database...");
                conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

                System.out.println("Creating statement...");
                String sql = "UPDATE usuario SET contrasena = ? WHERE correo LIKE " + "'" + mysqlemail + "'";
                stmt = conn.prepareStatement(sql);
                stmt.setString(1, newpass);
                int rs = stmt.executeUpdate();
                System.out.println("La contraseña se ha cambiado con exito");
                System.out.println(rs);
                NuevaContrasena.hide();

                stmt.close();
                conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (stmt != null) {
                        stmt.close();
                    }
                } catch (SQLException se2) {
                }
                try {
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException se) {
                    se.printStackTrace();
                }


            }

        } else {
            JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden.");
        }
    }

    public void onbuttoncancelar(ActionEvent actionEvent) {
        if (CONECTADO == false) {
            JOptionPane.showMessageDialog(null, "Debes estar registrado para acceder a esta función.");
        }
        if (CONECTADO == true) {
            int input = JOptionPane.showConfirmDialog(null, "¿Seguro que desea cancelar esta reserva?");
            if (input==0){

                Connection conn = null;
                PreparedStatement stmt = null;
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");

                    System.out.println("Connecting to database...");
                    conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

                    System.out.println("Creating statement...");
                    String sql = "UPDATE habitaciones SET disponible = 0 WHERE id_habitacion LIKE 1";
                    stmt = conn.prepareStatement(sql);
                    int rs = stmt.executeUpdate();
                    System.out.println("Reserva realizada con exito");
                    System.out.println(rs);

                    sql = "DELETE FROM reservas WHERE idreserva = ? AND correousuario = ?";
                    stmt = conn.prepareStatement(sql);
                    stmt.setString(1, cancelartx.getText().toString());
                    stmt.setString(2, EmailUsuario2);
                    int rs2 = stmt.executeUpdate();
System.out.println("Cancelacion realizada correctamente");
                    stmt.close();
                    conn.close();
                } catch (SQLException se) {
                    se.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (stmt != null) {
                            stmt.close();
                        }
                    } catch (SQLException se2) {
                    }
                    try {
                        if (conn != null) {
                            conn.close();
                        }
                    } catch (SQLException se) {
                        se.printStackTrace();
                    }
                }
            }
        }

        labeldateneeded.setText("");
        labeldateneeded2.setText("");
        labelreservado.setText("");
        room1pane.setDisable(false);
        labeldisponibleapartir.setText("");
        labelfechadisponible.setText("");

    }


    public static class Mail {
        /**
         * Clase para enviar emails.
         */
        private Properties properties;
        private Session session;

        public Mail(String ruta) throws IOException {
            this.properties = new Properties();
            loadConfig(ruta);

            session = Session.getDefaultInstance(properties);
        }

        private void loadConfig(String ruta) throws InvalidParameterException, IOException {
            InputStream is = new FileInputStream(ruta);
            this.properties.load(is);
            checkConfig();
        }

        private void checkConfig() throws InvalidParameterException {

            String[] keys = {
                    "mail.smtp.host",
                    "mail.smtp.port",
                    "mail.smtp.user",
                    "mail.smtp.password",
                    "mail.smtp.starttls.enable",
                    "mail.smtp.auth"
            };

            for (int i = 0; i < keys.length; i++) {
                if (this.properties.get(keys[i]) == null) {
                    throw new InvalidParameterException("No existe la clave " + keys[i]);
                }
            }

        }

        public void enviarEmail(String asunto, String mensaje, String correo) throws MessagingException {

            MimeMessage contenedor = new MimeMessage(session);
            contenedor.setFrom(new InternetAddress((String) this.properties.get("mail.smtp.user")));
            contenedor.addRecipient(Message.RecipientType.TO, new InternetAddress(correo));
            contenedor.setSubject(asunto);
            contenedor.setText(mensaje);
            Transport t = session.getTransport("smtp");
            t.connect((String) this.properties.get("mail.smtp.user"), (String) this.properties.get("mail.smtp.password"));
            t.sendMessage(contenedor, contenedor.getAllRecipients());

        }

        public void enviarEmail(String asunto, String mensaje, String[] correos) throws MessagingException {

            MimeMessage contenedor = new MimeMessage(session);
            contenedor.setFrom(new InternetAddress((String) this.properties.get("mail.smtp.user")));
            for (int i = 0; i < correos.length; i++) {
                contenedor.addRecipient(Message.RecipientType.TO, new InternetAddress(correos[i]));
            }
            contenedor.setSubject(asunto);
            contenedor.setText(mensaje);
            Transport t = session.getTransport("smtp");
            t.connect((String) this.properties.get("mail.smtp.user"), (String) this.properties.get("mail.smtp.password"));
            t.sendMessage(contenedor, contenedor.getAllRecipients());

        }

    }


}